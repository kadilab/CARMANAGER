<?php 
    //index.php
    require_once '../config.php';
    $query = "SELECT * FROM cardetaille ORDER BY date";
    $result = mysqli_query($conn, $query);
    $chart_data = '';
    $i = 0;
    $newdate = date('2000-01-01');
    while($row = mysqli_fetch_array($result))
    {
  
          $newdates = $row['date'];
          if ($newdate != $row['date']){
                $newquery = "SELECT * FROM `cardetaille` WHERE date = '$newdates'";
                $rest =  mysqli_query($conn, $newquery);
                
                $chart_data .= "{ date:'".$row["date"]."', nombre:".$rest->num_rows."}, ";
            }
            $newdate = $row['date'];
     
    }
     $chart_data = substr($chart_data, 0, -2);

  //  var_dump($chart_data);
?>


<!DOCTYPE html>
<html>
 <head>
  <title>chart with PHP & Mysql | lisenme.com </title>
  <link rel="stylesheet" href="morris.css">
  
      <div id="chart"></div>
 </body>
</html>
<script>
    Morris.Bar({
    element : 'chart',
    data:[<?php echo $chart_data; ?>],
    xkey:'date',
    ykeys:['nombre'],
    labels:['voiture'],
    hideHover:'auto',
    stacked:true
    });
</script>