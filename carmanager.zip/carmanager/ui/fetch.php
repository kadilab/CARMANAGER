<?php
//fetch.php
require_once 'config.php';
$output = '';
$query = "";
if(isset($_POST["query"]))
{
    $search = mysqli_real_escape_string($conn, $_POST["query"]);
    $query = " SELECT *FROM cardetaille WHERE immatriculation LIKE '%$search%' OR type LIKE '%$search%' ";
}
else
{
    $query = "SELECT *FROM cardetaille LIMIT 10";
}

$result = $conn-> query($query);

if(mysqli_num_rows($result) > 0)
{
 $output .= '
 <table class="table table-hover table-striped">
 <thead>
     <th>ID</th>
     <th>imatriculation</th>
     <th>TYPE</th>
     <th>DATE</th>
     <th>HEURE</th>
     
 </thead>
 ';
  $i= 0;
 while($row = $result -> fetch_assoc())
 {
    $i++;
  $output .= '
   <tbody>
        <tr>
           <td scope="row">'.$i.'</td>
           <td>'.$row['immatriculation'].'</td>
           <td>'.$row['type'].'</td>
           <td>'.$row['date'].'</td>
           <td>'.$row['heure'].'</td>
        
 </tr> 
  ';
 }
    echo $output.' </tbody>
 </table>';
}
else
{
    echo '<img src="empty.png" alt="" style="padding-left: 35%;" srcset="">';
}

?>