<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car manager</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body>
        <div class="container" style="margin-top: 10%; margin-left: 30%;">
            <div class="card" style="width: 500px;">
                <div class="card-header">
                    <h4 class="card-title">LOGIN </h4>
                </div>
                <div class="card-body">
                    <form method="post" action="auth.php">
                            <div class="col-md-10 pl-1">
                                <div class="form-group">
                                    <input type="email" class="form-control" name="email" required placeholder="Email">
                                </div>
                            </div>
                            <div class="col-md-10 pl-1">
                                <div class="form-group">
                        
                                    <input type="password" class="form-control" name="password" required placeholder="Mot de passe">
                                </div>
                            </div>
                        <button type="submit" name="submit" class="btn btn-info btn-fill pull-right">Connexion</button>
                        <div class="clearfix"></div>
                    </form>
                </div>
            </div>
        </div>
      
</body>
</html>