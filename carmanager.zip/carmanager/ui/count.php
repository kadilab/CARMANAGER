<?php      
            require_once 'config.php';
            include "layout/head.php";
            $date = date("Y-m-d");
            $sql = "SELECT *FROM cardetaille WHERE date ='$date'";
            $result = $conn-> query($sql);   
            $nombre =  $result->num_rows;
            $conn -> close();
    echo $nombre;
?>