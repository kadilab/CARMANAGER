-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : lun. 25 oct. 2021 à 14:19
-- Version du serveur : 10.4.21-MariaDB
-- Version de PHP : 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `licence`
--

-- --------------------------------------------------------

--
-- Structure de la table `cardetaille`
--

CREATE TABLE `cardetaille` (
  `id` int(11) NOT NULL,
  `immatriculation` varchar(20) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `heure` time NOT NULL DEFAULT current_timestamp(),
  `type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `cardetaille`
--

INSERT INTO `cardetaille` (`id`, `immatriculation`, `date`, `heure`, `type`) VALUES
(1, '23ABC788', '2021-10-25', '14:18:57', 'toyota'),
(2, 'JKDS998', '2021-10-25', '17:18:57', 'VOLVO'),
(3, '23ABC788', '2021-10-28', '20:07:30', 'toyota'),
(4, '23ABC788', '2021-10-24', '22:11:12', 'TOTA'),
(5, '0703ac19', '2021-10-27', '00:00:00', 'Sedan'),
(6, '0703ac19', '2021-10-24', '838:59:59', 'Sedan'),
(7, '0703ac19', '2021-10-26', '838:59:59', 'Sedan'),
(8, '0703ac19', '2021-10-25', '00:00:00', 'Sedan'),
(9, '0703ac19', '2021-10-26', '838:59:59', 'Sedan'),
(10, '0703ac19', '2021-10-26', '00:00:00', 'Sedan'),
(11, '0703ac19', '2021-10-25', '00:00:00', 'Sedan'),
(12, '0703ac19', '2021-10-25', '00:00:00', 'Sedan'),
(13, 'pijae0s0', '2021-10-25', '00:00:00', 'Sedan'),
(14, '0703ac19', '2021-10-25', '00:00:00', 'Sedan'),
(15, 's22jvf02', '2021-10-25', '838:59:59', 'Big Truck'),
(16, 'mh8sss8', '2021-10-25', '00:00:00', 'Sedan'),
(17, '0703ac19', '2021-10-25', '838:59:59', 'Sedan');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `email`, `password`) VALUES
(1, 'kadiata020@gmail.com', 'admin');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `cardetaille`
--
ALTER TABLE `cardetaille`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `cardetaille`
--
ALTER TABLE `cardetaille`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
