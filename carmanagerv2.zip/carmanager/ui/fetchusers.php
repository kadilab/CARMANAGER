<?php

require_once 'config.php';

$query = "SELECT *FROM users";
$output = '';
$result = $conn-> query($query);

if(mysqli_num_rows($result) > 0)
{
 $output .= '
 <table class="table table-hover table-striped">
 <thead>
    <th>N</th>
    <th>NOM</th>
    <th>EMAIL</th>                                              
    <th>action</th>   
 </thead>
 ';
  $i= 0;
 while($row = $result -> fetch_assoc())
 {
    $i++;
  $output .= '
   <tbody>
   <tr>
        <td scope="row">'.$i.'</td>
        <td>'.$row['nom'].'</td>
        <td>'.$row['email'].'</td>
        <td>
            <form action="dell.php" method="post">
                 <input name="id" type="hidden" value='.$row['id'].'>
                 <button onclick="update()" class="btn btn-danger">Supprimer</button>
            </form>
        </td>
    </tr> 
  ';
 }
    echo $output.' </tbody></table>';
}
else
{
    echo '<img src="empty.png" alt="" style="padding-left: 35%;" srcset="">';
}

?>