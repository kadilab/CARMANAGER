<?php
  $host = "localhost";
  $username = "root";
  $pass = "";
  $dbname = "licence";
  $conn = new mysqli("$host","$username","$pass","$dbname");
  if ($conn -> connect_errno) {
     echo "Failed to connect to MySQL: " . $conn -> connect_error;
    exit();
  }
?>