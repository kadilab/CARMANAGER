<?php
     require_once 'config.php';
    $plate = $_GET['plate'];
    $type = $_GET['type'];
    $date = date("Y-m-d");
    $heure = time();
    $query = "INSERT INTO `cardetaille`(`id`, `immatriculation`, `date`, `heure`, `type`) VALUES (null,'$plate','$date','$heure','$type')";
    $result = $conn-> query($query);   
    echo $query;
?>