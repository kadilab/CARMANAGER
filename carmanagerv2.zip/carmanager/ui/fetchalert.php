<?php

require_once 'config.php';

$query = "SELECT *FROM alerte";
$output = '';
$result = $conn-> query($query);

if(mysqli_num_rows($result) > 0)
{
 $output .= '
 <table class="table table-hover table-striped">
 <thead>
    <th>N</th>
    <th>Immatriculation</th>
    <th>ACTION</th>                                                
 </thead>
 ';
  $i= 0;
 while($row = $result -> fetch_assoc())
 {
  $i++;
  if($row['etat']==0){
    $output .= '
    <tbody>
    <tr>
         <td scope="row">'.$i.'</td>
         <td>'.$row['matricule'].'</td>
         <td>
             <form action="Alert.php" method="post">
                  <input name="id" type="hidden" value='.$row['id'].'>
                  <button name="find" class="btn btn-primary">Trouver</button>
             </form>
         </td>
     </tr> 
   ';
  }
 }
    echo $output.' </tbody></table>';
}
else
{
    echo '<img src="empty.png" alt="" style="padding-left: 35%;" srcset="">';
}

?>