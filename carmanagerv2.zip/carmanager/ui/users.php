<?php
   require_once 'config.php';

   if (isset($_POST['add'])) {

      $nom = $_POST['nom'];
      $email = $_POST['email'];
      $password = $_POST['password'];
      $query = "INSERT INTO `users` (`id`, `nom`, `email`, `password`) VALUES (NULL, '$nom', '$email', '$password')";
      $result = $conn-> query($query);
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php
            include "layout/head.php";
        ?>
</head>
<body>
    <div class="wrapper">
        <!-- side bar -->
        <?php
         $change = 5;
            include "layout/side_bar.php";
        ?>
        <!-- end side bar -->
        <div class="main-panel">
            <!-- Navbar -->
            <?php
                 
                  include "layout/nav.php";
           ?>
            <!-- End Navbar -->
            <!-- End Navbar -->
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Ajouter Utilisateur</h4>
                                </div>
                                <div class="card-body">
                                    <form action="users.php" method="post">
                                      <div class="row">
                                            <div class="col-md-6 pl-3">
                                                <div class="form-group">
                                                    
                                                    <input type="text" name="nom" class="form-control" required placeholder="Nom d'utilisateur">
                                                </div>
                                            </div>
                                            
                                        </div>
                                        <div class="row">
                                         
                                            <div class="col-md-6 pl-3">
                                                <div class="form-group">
                                                    
                                                    <input type="email" name="email" class="form-control" required placeholder="Email">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6 pl-3">
                                                <div class="form-group">
                                                   
                                                    <input type="password" name="password" class="form-control" required placeholder="mot de passe">
                                                </div>
                                            </div>
                                        </div>
                                        <button  type="submit" name="add" class="btn btn-info btn-fill pull-right">Ajouter</button>
                                        <div class="clearfix"></div>
                                    </form>
                                    <div class="card-body table-full-width table-responsive">
                                             <div id="result"></div>
                                     </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card card-user" style="margin-top : 50px;">
                                <div class="card-body">
                                    <div class="author">
                                        <a href="#">
                                            <img class="avatar border-gray" src="../assets/img/faces/face-3.jpg" alt="...">
                                            <h5 class="title">jonathan</h5>
                                        </a>
                                        <p class="description">
                                            kadiata020@gmail.com
                                        </p>
                                    </div>
                                </div>                              
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <footer class="footer">
                <div class="container-fluid">
                    <nav>
                        
                        <p class="copyright text-center">
                            ©
                            <script>
                                document.write(new Date().getFullYear())
                            </script>
                            <a href="http://www.creative-tim.com">smaraf</a>, made with love for a better web
                        </p>
                    </nav>
                </div>
            </footer>
        </div>
    </div>
</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="../assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="../assets/js/core/bootstrap.min.js" type="text/javascript"></script>
<!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
<script src="../assets/js/plugins/bootstrap-switch.js"></script>
<!--  Google Maps Plugin    -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!--  Chartist Plugin  -->
<script src="../assets/js/plugins/chartist.min.js"></script>
<!--  Notifications Plugin    -->
<script src="../assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Light Bootstrap Dashboard: scripts for the example pages etc -->
<script src="../assets/js/light-bootstrap-dashboard.js?v=2.0.0 " type="text/javascript"></script>
<!-- Light Bootstrap Dashboard DEMO methods, don't include it in your project! -->
<script src="../assets/js/demo.js"></script>
<script>
    update();
    function update()
    {
        $('#result').load("fetchusers.php");
    }


    function load_data(query)
    {
        $.ajax({
        url:"addusers.php",
        method:"POST",
        data:{query:query},
        });
    }
</script>
</html>
