<?php
  echo "Aucun resultat enregistre.";
?>