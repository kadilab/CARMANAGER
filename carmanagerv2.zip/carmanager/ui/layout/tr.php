<tr>
           <td><?=$i?></td>
           <td><?=$row['immatriculation']?></td>
           <td><?=$row['type']?></td>
           <td><?=$row['date']?></td>
           <td><?=$row['heure']?></td>
           <td>
         <form action="#" method="post">
              <input type="hidden" name="<?=$row['id']?>">
              <button class="btn btn-success"> view</button>
           </form>
        </td>
 </tr> 