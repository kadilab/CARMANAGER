<div class="sidebar" data-image="../assets/img/sidebar-6.jpg">
            <div class="sidebar-wrapper">
                <div class="logo">
                    <a href="http://www.creative-tim.com" class="simple-text">
                        CAR MANAGER
                    </a>
                </div>
                <ul class="nav">
                    <li class="nav-item <?php
                       if($change == 1)
                            echo "active"; 
                    ?>">
                        <a class="nav-link" href="home.php">
                            <i class="nc-icon nc-chart-pie-35"></i>
                            <p>Dashboard</p>
                        </a>
                    </li> 
                    <li class="nav-item  <?php
                       if($change == 2)
                            echo "active"; 
                    ?>">
                        <a class="nav-link" href="./table.php">
                            <i class="nc-icon nc-notes"></i>
                            <p>Liste de voitures</p>
                        </a>
                    </li>
                    <li class="nav-item <?php
                       if($change == 3)
                            echo "active"; 
                    ?>">
                        <a class="nav-link" href="./camera.php">
                            <i class="nc-icon nc-cctv"></i>
                            <p>Camera</p>
                        </a>
                    </li>
                    <li class="nav-item <?php
                       if($change == 4)
                            echo "active"; 
                    ?>">
                        <a class="nav-link" href="./alert.php">
                            <i class="nc-icon nc-bell-55"></i>
                            <p>Alerte</p>
                        </a>
                    </li>
                    <li class="nav-item <?php
                       if($change == 5)
                            echo "active"; 
                    ?>">
                        <a class="nav-link" href="./users.php">
                            <i class="nc-icon nc-circle-09"></i>
                            <p>Utilisateur</p>
                        </a>
                    </li>
                    <li class="nav-item active active-pro">
                        <a class="nav-link active" href="smaraf.com">
                            <i class="nc-icon nc-alien-33"></i>
                            <p>SMARAF TEAM</p>
                            
                        </a>
                    </li>
                </ul>
            </div>
        </div>