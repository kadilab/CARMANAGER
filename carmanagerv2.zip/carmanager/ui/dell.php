<?php
    require_once 'config.php';
   if (isset($_POST['id'])) {
       $id = $_POST['id'];
       $query = "DELETE FROM `users` WHERE id='$id'";
       $result = $conn-> query($query);
       header("Location: users.php");
   }
?>