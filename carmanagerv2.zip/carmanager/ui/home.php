<!DOCTYPE html>
<?php
  session_start();
  if (!isset($_SESSION['email'])) {
    header("Location: index.php");
  }
?>
<html lang="en">

<head>
    <?php      
            require_once 'config.php';
            include "layout/head.php";
            $date = date("Y-m-d");
            $sql = "SELECT *FROM cardetaille WHERE date ='$date'";
            $result = $conn-> query($sql);   
            $nombre =  $result->num_rows;
            $conn -> close();
        ?>
</head>

<body>
    <div class="wrapper">
        <!-- side bar -->
        <?php
             $change = 1;
            include "layout/side_bar.php";
        ?>
        <!-- end side bar -->
        <div class="main-panel">
            <!-- Navbar -->
            <?php
                  include "layout/nav.php";
           ?>
            <!-- End Navbar -->
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="card ">
                                <div class="card-header ">
                                    <h4 class="card-title">Statistique du jour</h4>
                                    <p class="card-category">voiture scanner</p>
                                </div>
                                <div class="card-body ">
                                    <h1 id="nombre"><?=$nombre?></h1>

                                    <hr>
                                    <div class="stats">
                                        <i class="fa fa-clock-o"></i>

                                        <?php
                                             echo date('l jS \of F Y h:i:s A');
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="card ">
                                <div class="card-header ">
                                    <h4 class="card-title">Statistique gblobal</h4>
                                    <p class="card-category">2021</p>
                                </div>
                                <div class="card-body ">
                                    <div class="container" style="width:auto;">

                                        <div id="charts"></div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <footer class="footer">
                <div class="container-fluid">
                    <nav>

                        <p class="copyright text-center">
                            ©
                            <script>
                            document.write(new Date().getFullYear())
                            </script>
                            <a href="http://www.smaraf.com">smaraf</a>, made with love for a better web
                        </p>
                    </nav>
                </div>
            </footer>
        </div>
    </div>
</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="../assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="../assets/js/core/bootstrap.min.js" type="text/javascript"></script>
<!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
<script src="../assets/js/plugins/bootstrap-switch.js"></script>
<!--  Google Maps Plugin    -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!--  Chartist Plugin  -->
<script src="../assets/js/plugins/chartist.min.js"></script>
<!--  Notifications Plugin    -->

<!-- Control Center for Light Bootstrap Dashboard: scripts for the example pages etc -->
<script src="../assets/js/light-bootstrap-dashboard.js?v=2.0.0 " type="text/javascript"></script>
<!-- Light Bootstrap Dashboard DEMO methods, don't include it in your project! -->
<script src="../assets/js/demo.js"></script>
<script type="text/javascript">
$(document).ready(function() {
    // Javascript method's body can be found in assets/js/demos.js
    demo.initDashboardPageCharts();

    demo.showNotification();

});
</script>
<script>
setInterval(function() {
    $("#charts").load("char/graphe.php");
}, 500);
setInterval(function() {
    $("#nombre").load("count.php");
}, 500);
</script>

</html>