<?php
  session_start();
?>
<?php
   require_once  'config.php';
  if(isset($_POST['submit']))
  {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $query = "SELECT * FROM `users` WHERE email = '$email' AND `password` = '$password'";

    $result = $conn-> query($query);
    
    var_dump($result);
    if($result->num_rows > 0)
    {
        $_SESSION['email'] = $_POST['email'];
        header("Location: home.php");
        
    }
    else
    {
        header("Location: index.php");
    }

  }

?>